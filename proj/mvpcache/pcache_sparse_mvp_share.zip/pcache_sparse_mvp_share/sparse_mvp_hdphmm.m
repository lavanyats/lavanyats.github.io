%This is the collapsed version!!
function [Z lambda b ll pkl beta model lambdaAll]= sparse_mvp_hdphmm(datafile,maxIter,outfile,trmodel,type_param,param_a)
	%Input : can pass either data file or data array and number of iterations

	%data expected - matrix -  rows increasing along time and columns are features 
	%type=2 : Diagonal covariance
	%type=0 : Full covariance
	type=0;
	%exist('type_param')  
	%~isempty(type_param)
	if exist('type_param') && ~isempty(type_param)
		type=type_param;
	end
	%type
	%keyboard

	global target;
	target=2;
	%parameters - for now, no hyper parameter sampling
	al=1;bl=1;   
	alpha=1;gamma=1 %concentration parameters of hdp

	%From MVP code 
	global VERY_SMALL_LOG;
	global VERY_SMALL_NUMBER;
	VERY_SMALL_LOG=-1000000000;
	VERY_SMALL_NUMBER=0.00000001;
	rng(2);
	randomseed([3 4 5]);

	if isempty(maxIter) maxIter=100; 
	end %number of gibbs iterations
	display(sprintf('Maximum gibbs iter = %d',maxIter));

	if isempty(outfile)
		outfile='res_mvp_hdphmm.mat';
	end

	data=[];
	if ischar(datafile) data=csvread(datafile);
	else data=datafile;
	end
	%csvwrite('sdpatrain.csv',data);

	%data=data+(rand()>0.5);

	global logtable;
	logtable=createlogtable(data);


	data=data ;
	[T M]=size(data)
	K=0;
	ajl=zeros(M,M); ajl(:,:)=al;
	bjl=zeros(M,M); bjl(:,:)=bl;

	ab=1*ones(1,M);
	bb=1*ones(1,M);
	aw=1*ones(1,M);
	bw=1*ones(1,M);

	gammalnajl=gammaln(ajl(:,:));
	gammalnbjl=gammaln(bjl(:,:));
	lambdaAll=zeros(K+1,M,M);
	lambda=[];
	lambdaW=[];
	ajl=100*ones(M,M); %For WEBA trace
	bjl=1*ones(M,M);
        if ~exist('param_a')
                ajl=200*ones(M,M);
        else  
                ajl=param_a*ones(M,M);
        end

	if type==2 ajl=ajl.*eye(M); end

	%ajl=sqrt(ones(M,M).*mean(data(find(data>=0))));%ajl = tridiag(1,1,1,M);
	ajl
	%ajl=sqrt(ones(M,M).*mean(data(find(data>0))));%ajl = tridiag(1,1,1,M);

	global mask;
	global maskb;
	mask=ajl>0;
	for j=1:M
		for l=1:M
			if j>l mask(j,l)=0; end
		end
	end
	maskb=mask;

	%Random variables to be sampled
	Z=ones(1,T);
	Z(:,:)=-1;
	Y=zeros(T,M,M);%We have declared a full matrix here though it is required to have only m*(m+1)/2 items.
	for t=1:T
		for j=1:M
			Y(t,j,j)=diag(data(t,j));
       		end
	end
	

	mcount=size(1,K+1);
	beta=ones(1,K+1);

	mcount(1)=1;mcount(2)=gamma;
	beta(K+1)=alpha;
	beta=normalize(beta);
	%Initialize with 0 topics
	numk=zeros(1,K+1);
	numkl=zeros(K+1,K+1);
	b=ones(K+1,M);

	numcj=K.*ones(1,M);
	size(numcj)
	numwj=zeros(1,M);
	y_sum_kjl=zeros(K+1,M,M);
	y_prod_kjl=zeros(K+1,M,M);
	w_sum_j=zeros(1,M);
	mcount(1)=gamma;
	beta(1)=1;

	if exist('trmodel') && ~isempty(trmodel)
		mcount=trmodel.mcount;
		numkl=trmodel.numkl;
		numk=trmodel.numk;
		y_sum_kjl=trmodel.y_sum_kjl;
		beta=trmodel.beta;
		mask=trmodel.mask;
		lambda=trmodel.lambda;
		lambdaAll=trmodel.lambdaAll;
		alpha=trmodel.alpha;
		gamma=trmodel.gamma;
		al=trmodel.al;
		bl=trmodel.bl;
		gammalnajl=trmodel.gammalnajl;
		gammalnbjl=trmodel.gammalnbjl;
		mask=trmodel.mask;
		ajl=trmodel.ajl;
		bjl=trmodel.bjl;
		K=trmodel.K;
		numcj=trmodel.numcj;
		numwj=trmodel.numwj;
		y_prod_kjl=trmodel.y_prod_kjl;
		ab=trmodel.ab;
		bb=trmodel.bb;
		aw=trmodel.aw;
		bw=trmodel.bw;
		maskb=trmodel.maskb;
		b=trmodel.b;
		w_sum_j=trmodel.w_sum_j;
	end

	total_timerval=tic;
	Z_old=Z;
	
	iter_time_arr=[];
	ll_arr=[];

	%Actually sampling
	for iter=1:maxIter
	        display(sprintf('sparse_mvp_hdphmm Type %d  Gibbs iter %d/%d, K=%d\n',type,iter,maxIter,K));
		iter_time=tic;
		tic
	        for t=1:T
			  if ~mod(t,200) 
				  toc
				  display(sprintf('sparse_mvp_hdphmm Type %d Gibbs iter iter=%d t= %d/%d K=%d \n',type,iter,t,T,K));  
				  tic
	     	    		  %ll=llikelihood(data(:,:),Z,lambda,b);
		    	  end
		    z_old=Z(t);
		    if t>1  z_prev=Z(t-1); else z_prev=-1; 
		    end
		    if t<T && iter~=1  z_next=Z(t+1); else z_next=-1; 
		    end
		    if iter~=1
			    [numk numkl  K y_sum_kjl y_prod_kjl beta mcount w_sum_j]=remove(t,z_old,z_prev,z_next,numk,numkl,b,K,M,beta,mcount,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j);
	    	    end		    
		    [Z(t) y_sum_kjl y_prod_kjl lambdaAll w_sum_j numwj]= sample_z_collapsed(t,Z,numkl,numk,numcj,numwj,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,aw,bw,ab,bb,lambdaAll,b);
		    if Z(t) == K+1
			    if type~=1 && type~=2 [b, numcj,numwj,w_sum_j]= sample_b(b,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,ab,bb,aw,bw,numcj,numwj);  end
		    end

		    [numk numkl K y_sum_kjl y_prod_kjl,beta mcount Z lambdaAll lambda b numcj w_sum_j]=addcompact(t,Z(t),z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,y_sum_kjl,y_prod_kjl,Z,lambdaAll,lambda,b,numcj,w_sum_j);

		    bind=find(b(Z(t),:)>0);
		    if iter==1 || sum(data(t,:))>0
	        	    for j=bind
        	            	   for l=bind
	        	                  if(j<l)&&ajl(j,l)~=0  
						  [Y y_sum_kjl,y_prod_kjl,lambdaAll]= sample_yjl_fast_collapsed(t,j,l,Z,numk,data,Y,y_sum_kjl,y_prod_kjl,ajl,bjl,lambdaAll,logtable);
	            	   		  end
			    	   end
        		    end
		    end

	      end
	      toc;
	      %sample the b
	      if type~=1 && type~=2 [b, numcj,numwj,w_sum_j]= sample_b(b,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,ab,bb,aw,bw,numcj,numwj); end
	      if type~=1 && type~=2 [b, numcj,numwj,w_sum_j]= sample_b(b,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,ab,bb,aw,bw,numcj,numwj); end
	      if type~=1 && type~=2 [b, numcj,numwj,w_sum_j]= sample_b(b,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,ab,bb,aw,bw,numcj,numwj); end
	     Z_old=Z;
	     display(sprintf('gibbs iter %d %d \n',iter,t));
	     %numk
	     mcount=sample_m(beta,numk,alpha,gamma,K); 
	     beta=sample_beta(mcount);
	     

	     [lambda lambdaW lambdaAll]=estimateLambda(Z,Y,data,b,ajl,bjl,aw,bw,K,y_sum_kjl,numk,numwj,w_sum_j);

	     ll=llikelihood(data(:,:),Z,lambda,b);
	     ll_arr=[ll_arr ll];

	     model.lambda=lambda;
	     model.Z=Z;
	     model.iter_time_arr=iter_time_arr;
	     model.beta=beta;
	     model.Z=Z;
	     model.ll=ll;
	     model.b=b;
	     model.Y=Y;
             model.mcount=mcount;
	     model.numkl=numkl;
	     model.numk=numk;
	     model.y_sum_kjl=y_sum_kjl;
	     model.w_sum_j=w_sum_j;
	     model.beta=beta;
	     model.mask=mask;
	     model.lambda=lambda;
	     model.lambdaAll=lambdaAll;
	     model.alpha=alpha;
	     model.gamma=gamma;
	     model.al=al;
	     model.bl=bl;
	     model.gammalnajl=gammalnajl;
	     model.gammalnbjl=gammalnbjl;
	     model.mask=mask;
	     model.ajl=ajl;
	     model.bjl=bjl;
	     model.K=K;
	     model.numcj=numcj;
	     model.numwj=numwj;
	     model.y_prod_kjl=y_prod_kjl;
	     model.ab=ab;
	     model.bb=bb;
	     model.aw=aw;
	     model.ll_arr=ll_arr;

	     save(outfile,'-struct','model');
	     display(sprintf('likelihood = %f with K=%d\n',ll,K));
	     iter_time_arr(iter)=toc(iter_time);
       	end
        total_elapsed_time=toc(total_timerval);;

	%Find transition probabilities
	pkl=zeros(K,K);
	for k=1:K
	  pkl(k,:)=numkl(k,1:K)./sum(numkl(k,1:K));
	end
	pk=numk(1:K)/sum(numk(1:K));

	%Find mean parameter
	[lambda lambdaW lambdaAll]=estimateLambda(Z,Y,data,b,ajl,bjl,aw,bw,K,y_sum_kjl,numk,numwj,w_sum_j);

	model.lambda=lambda;
	model.pkl=pkl;
	model.pk=pk;
	model.beta=beta;
	model.Z=Z;
	model.ll=ll;
	model.numkl=numkl;
	model.numk=numk;
	model.b=b;
	model.Y=Y;
	model.total_elapsed_time=total_elapsed_time;
	model.iter_time_arr=iter_time_arr;

        model.mcount=mcount;
	model.numkl=numkl;
	model.numk=numk;
	model.y_sum_kjl=y_sum_kjl;
	model.w_sum_j=w_sum_j;
	model.beta=beta;
	model.mask=mask;
	model.lambda=lambda;
	model.lambdaAll=lambdaAll;
	model.alpha=alpha;
	model.gamma=gamma;
	model.al=al;
	model.bl=bl;
	model.gammalnajl=gammalnajl;
	model.gammalnbjl=gammalnbjl;
	model.mask=mask;
	model.ajl=ajl;
	model.bjl=bjl;
	model.K=K;
	model.numcj=numcj;
	model.numwj=numwj;
	model.y_prod_kjl=y_prod_kjl;
	model.ab=ab;
	model.bb=bb;
	model.aw=aw;
	model.bw=bw;
	model.ll=ll;
	model.ll_arr=ll_arr;
	model.maskb=maskb;
	if exist('trmodel') && ~isempty(trmodel)
		model.prevll=trmodel.ll;
	end

	%Now estimate the state sequence Z using the viterbi algorithm to get a proper estimate of the state sequence
	model.Z=Z;

	save(outfile,'-struct','model');
	Z=Z'; 
	if exist('trmodel') && ~isempty(trmodel)
		display(sprintf('obtained %d clusters previously with likelihood=%f',trmodel.K,trmodel.ll));
	end
	display(sprintf('obtained %d clusters with likelihood=%f',size(lambda,1),ll));

end

function [z y_sum_kjl_out y_prod_kjl_out lambdaAll_out w_sum_j_out numwj_out]=sample_z_collapsed(t,Z,numkl,numk,numcj,numwj,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,aw,bw,ab,bb,lambdaAll,b)
	VERY_SMALL_LOG=-1000000000;
	VERY_SMALL_NUMBER=0.00000001;
	z_old=Z(t);
	[T M]=size(data);
	p=zeros(1,K+1);
	for k=1:K+1
		term_prev=1; if t>1 term_prev=(numkl(Z(t-1),k)+alpha*beta(k)); end
		term_next=1; if (t<size(data,1) && Z(t+1)~=-1)  term_next = (numkl(k,Z(t+1))+alpha*beta(Z(t+1)))/ (numk(k)+alpha) ; end
		emis=VERY_SMALL_LOG;
		if Z(t)>=0
			bind=find(b(Z(t),:)>0);
		else
			bind=ones(M);
		end

		if k==K+1
			MH_STEPS=10;
			s=0;
			emis_exp=0;
			b_old=ones(1,M);
			if z_old > 0
				b_old=b(z_old,:);
			end
			while s<MH_STEPS
				%propose new value for b				
				%generage b_k+1 sample somehow 
				[b(K+1,:) pr numSamples]=generateMHSample(b_old,0.2,ab,bb,numcj,K);
				emis_temp=logemissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl,b);
				emis_temp=emis_temp+logemissionWCollapsed(t,k,Z,numk,data,Y,w_sum_j,aw,bw,b);
				emis_exp=logWeightedAverage(emis_exp, emis_temp,s,1);
				s=s+1;
				b_old=b(K+1,:);
			end
			b(K+1,:)=1;
			emis=emis_exp;
		else
			emis=logemissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl,b);
			emis=emis+logemissionWCollapsed(t,k,Z,numk,data,Y,w_sum_j,aw,bw,b);
		end

	        if term_prev==0 || term_next==0
		    p(1,K)=VERY_SMALL_NUMBER;
	        else 
	    		p(1,k)=log(term_prev)+log(term_next)+emis;
		end
	    	if isnan(p(1,k))
		    [k K]
		    p
	    	    term_prev
		    term_next
		    emis
		    w_sum_j
		    display(sprintf('k=%d termprev %f termnext %f emis %f p(1,k) %f \n',k,term_prev,term_next,emis,p(1,k)));
		    keyboard
	    	end
	end	

	if ~isreal(p) 
		display('in sample z');
		p
		keyboard; 
	end
	z=sampleLogMult(p);

	if z==K+1
		y_sum_kjl(z,:,:)=Y(t,:,:);
		y_prod_kjl(z,:,:)=gammaln(Y(t,:,:)+1);
		for j=1:M 
			for l=1:M
				if j>l continue; end
				if ajl~=0 	
					lambdaAll(z,j,l)=gamrnd(y_sum_kjl(z,j,l)+ajl(j,l),1/(bjl(j,l)+1)); 
					lambdaAll(k,l,j)=lambdaAll(z,j,l); 
				end
			end 
		end
		lambdaAll(z+1,:,:)=0;

	else    
		y_sum_kjl(z,:,:)=y_sum_kjl(z,:,:)+Y(t,:,:);		
		y_prod_kjl(z,:,:)=y_prod_kjl(z,:,:)+gammaln(Y(t,:,:)+1);		
	end
	if z_old>0 numwj=numwj-(1-b(z_old,:));	end
	numwj=numwj+(1-b(z,:));
	w_sum_j=w_sum_j+(1-b(z,:)).*diag(squeeze(Y(t,:,:)))';
	y_sum_kjl_out=y_sum_kjl;
	y_prod_kjl_out=y_prod_kjl;
	lambdaAll_out=lambdaAll;
	w_sum_j_out=w_sum_j;
	numwj_out=numwj;
end

function [beta]=sample_beta(mcount)
	beta=drchrnd(mcount,1);
end

function [mcount]=sample_m(beta,numk,alpha,gamma,K)
mcount=zeros(1,K+1);
for k=1:K
		tot=numk(k);
		totsofar=0;
		for c=1:tot
			x=alpha*beta(k)/(alpha*beta(k)+totsofar);
			totsofar=totsofar+1;
			if rand()<x
				mcount(k)=mcount(k)+1;
			end
		end
	end
	mcount(K+1)=gamma;
end

function [em]=emissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl)
  em=exp(logemission(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl));
end

%This function is the slowest link. 
function [em]=logemissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl,b)
	global mask;
	global maskb;
	global logtable;
	bind=find(b(k,:)>=0);
	tmp(:,:)= - (permute(y_sum_kjl(k,bind,bind)+Y(t,bind,bind),[2,3,1])+ajl(bind,bind)) .* log(numk(k)+1+bjl(bind,bind)) +(permute(y_sum_kjl(k,bind,bind),[2 3 1])+ajl(bind,bind)) .* log(numk(k)+bjl(bind,bind)) -gammaln(permute(y_sum_kjl(k,bind,bind),[2 3 1])+ajl(bind,bind)) +gammaln(permute(y_sum_kjl(k,bind,bind)+Y(t,bind,bind),[2 3 1])+ajl(bind,bind)) -gammaln(permute(Y(t,bind,bind),[2 3 1])+1) ;	
	tmp(find(isnan(tmp)))=0;
	res(:,:)=sum(sum(tmp.*mask(bind,bind)));
	em=res;
end

function [em]=logemissionWCollapsed(t,k,Z,numk,data,Y,w_sum_j,aw,bw,b)
	global mask;
	global maskb;
	global logtable;
	bind=find(b(k,:)==0);
	[T M]=size(data);
	res=0;
	for j = bind
                	%the first gammaln is a replacement for logfactorial of one number lower
			res=res-gammaln(Y(t,j,j)+1) - (w_sum_j(j)+Y(t,j,j)+aw(j)) .* log(numk(k)+1+bw(j))  +(w_sum_j(j)+aw(j)) .* log(numk(k)+bw(j)) -gammaln(w_sum_j(j)+aw(j)) +gammaln(w_sum_j(j)+Y(t,j,j)+aw(j));
	end
	em=res;
end


function [lambda lambdaW lambdaAll]=estimateLambda(Z,Y,data,b,ajl,bjl,aw,bw,K,y_sum_kjl,numk,numwj,w_sum_j)
	[T,M]=size(data);
	lambdaAll=zeros(K+1,M,M);
	lambda=zeros(K,M);
	lambdaW=zeros(1,M);

	for j=1:M		
		lambdaW(j)=(w_sum_j(j)+aw(j)*1.0)/(bw(j)+numwj(j));
	end
	for k=1:K
		for j=1:M
			for l=1:M
				if b(k,j)==0 || b(k,l)==0 || j>l continue; end					
					lambdaAll(k,j,l)=(y_sum_kjl(k,j,l)+ajl(j,l)*1.0)/(bjl(j,l)+numk(k));
					lambdaAll(k,l,j)=lambdaAll(k,j,l);
			end
		end
	end
	for j=1:M
		for k=1:K
			if b(k,j)~=0
				lambda(k,j)=sum(lambdaAll(k,1:j-1,j))+sum(lambdaAll(k,j,j:M));
			else
				lambda(k,j)=lambdaW(j);
			end
		end	
	end	
end
function [lambda lambdaW lambdaAll]=sampleLambdaAll(Z,data,b,ajl,bjl,Y,K,y_sum_kjl,numk)
	[T,M]=size(data);
	lambdaAll=zeros(K+1,M,M);
	lambda=zeros(K,M);
	lambdaW=zeros(1,M);
	for j=1:M
		lambdaW(j)=gamrnd(w_sum_j(j)+aw(j),1/(bw(j)+numwj(j)));
	end
	for k=1:K
		for j=1:M
			for l=1:M
				if b(k,j)==0 || b(k,l)==0 continue; end
				if j>l continue; end
				if ajl(j,l)>0
					lambdaAll(k,j,l)=gamrnd(y_sum_kjl(k,j,l)+ajl(j,l),1/(bjl(j,l)+numk(k)));
					lambdaAll(k,l,j)=lambdaAll(k,j,l);
				else
					lambdaAll(k,j,l)=0;
				end
			end
		end
		%k
		%a(:,:)=lambdaAll(k,:,:)
		for j=1:M
			lambda(k,j)=sum(lambdaAll(k,1:j-1,j))+sum(lambdaAll(k,j,j:M));
		end		
	end
			
end


%z_prev is z_t-1
function [numk_o numkl_o K_o y_sum_kjl_o y_prod_kjl_o beta_o mcount_o w_sum_j_o]=remove(t,z_old,z_prev,z_next,numk,numkl,b,K,M,beta,mcount,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j)
	numk(z_old)=numk(z_old)-1; 
	if z_prev ~= -1              numkl(z_prev,z_old)=numkl(z_prev,z_old)-1;  end
	if z_next ~= -1   		numkl(z_old,z_next)=numkl(z_old,z_next)-1;  end
	for j=1:M 
		for l=1:M 
			if j>l continue; end 
			y_sum_kjl(z_old,j,l)=y_sum_kjl(z_old,j,l)-Y(t,j,l);
			y_prod_kjl(z_old,j,l)=y_prod_kjl(z_old,j,l)-gammaln(Y(t,j,l)+1);
			if y_sum_kjl(z_old,j,l)<0
				display(sprintf('caught ya!! %d %d %d  Y(t,j,l)=%d y_sum_kjl(z_old,j,l)=%d\n',z_old,j,l,Y(t,j,l),y_sum_kjl(z_old,j,l)+Y(t,j,l)));
			end
		end
	end
	w_sum_j=w_sum_j-(1-b(z_old,:)).*diag(squeeze(Y(t,:,:)))';

	numk_o=numk;
	numkl_o=numkl;
	K_o=K;
	y_sum_kjl_o=y_sum_kjl; 
	y_prod_kjl_o=y_prod_kjl;
	beta_o=beta;
	mcount_o=mcount;
	w_sum_j_o=w_sum_j;

end



function [b_out numcj_out,numwj_out,w_sum_j_out]= sample_b(b,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,y_prod_kjl,w_sum_j,ajl,bjl,ab,bb,aw,bw,numcj,numwj)
	%numcj is number of clusters for which j is active
	%num_wj is number of active ws for that particular j
	global target;
	[T M]=size(data);
	numcj_old=numcj;
	for k=1:K
		%cj : number of clusters in which feature j is active including the current cluster
		numcj(1,:)=numcj(1,:)-b(k,:);
		numwj(1,:)=numwj(1,:)-(1-b(k,:)).*numk(k);
		for j=1:M
			if b(k,j)==0 || (sum(y_sum_kjl(k,j,:))+sum(y_sum_kjl(k,:,j))-2*sum(y_sum_kjl(k,j,j)))<=0
				w_sum_j(j)=w_sum_j(j)-(1-b(k,j))*y_sum_kjl(k,j,j);
				if sum(w_sum_j<0)>0
					(1-b(k,j))
					y_sum_kjl(k,j,j)
					[k K j]

					w_sum_j
					display('wsumj prob 1');
					keyboard
				end
				p=zeros(1,2);
				for i =[0:1]
					if i==0
						p(i+1)=log(K+bb(j)-numcj(j)-i)-	log(K+ab(j)+bb(j)-1);
					else
						p(i+1)=log(numcj(j)+i+ab(j)-1)-log(K+ab(j)+bb(j)-1) ;
					end
					
					if ~isreal(p)  || sum(isnan(p))
						display('non real detected 1');
						i
						p
						K
						numcj
						numcj_old
						K+bb(j)-numcj(j)-i	
						K+ab(j)+bb(j)-1 
						keyboard; 
					end
					p(i+1)=i*log(numcj(j)+i+ab(j)-1+(1-i))+(1-i)*log(K+bb(j)-numcj(j)-i)-	log(K+ab(j)+bb(j)-1); 
					if ~isreal(p)  || sum(isnan(p))
						display('non real detected 2');
						i*log(numcj(j)+i+ab(j)-1)
						(1-i)*log(K+bb(j)-numcj(j)-i)
						log(K+ab(j)+bb(j)-1)
						i
						p
						keyboard; 
					end
					p(i+1)=p(i+1)+gammaln(aw(j)+w_sum_j(j)+(1-i)*y_sum_kjl(k,j,j)) - (aw(j)+w_sum_j(j)+(1-i)*y_sum_kjl(k,j,j)).*log(numwj(j)+(1-i)*numk(k)+bw(j))-(1-i)*y_prod_kjl(k,j,j);
					if ~isreal(p)  || sum(isnan(p))
						display('non real detected i3');
						i
						p
					        gammaln(aw(j)+w_sum_j(j)+(1-i)*y_sum_kjl(k,j,j)) 
						numwj
					       	numwj(j)+(1-i)*numk(k)+bw(j)
						(1-i)*y_prod_kjl(k,j,j);
						keyboard; 
					end
					p_old=p(i+1);
					if i==1
						for jt=1:M
							if jt~=j && b(k,jt)~=1 continue; end; 
							for lt=1:M
								if(jt>lt) || ajl(jt,lt)==0 continue; end;
								if lt~=j && b(k,lt)~=1 continue; end;
								if jt~=j && lt~=j continue; end;
								p(i+1)=p(i+1)+ajl(jt,lt).*log(bjl(jt,lt))-gammaln(ajl(jt,lt))+gammaln(ajl(jt,lt)+y_sum_kjl(k,jt,lt))-(ajl(jt,lt)+y_sum_kjl(k,jt,lt)).*log(numk(k)+bjl(jt,lt))-y_prod_kjl(k,jt,lt);
							end
						end
					end	
					%display(sprintf(' fourth k=%d j=%d i=%d  %f \n',k,j,i,p(i+1)-p_old));
					if ~isreal(p)  || sum(isnan(p))
						display('non real detected 3.5');
						i
						p
						keyboard; 
					end
				end
				if ~isreal(p) || sum(isnan(p))
					p
					keyboard; 
				end
				b(k,j)=sampleLogMult(p);
			       	b(k,j)=b(k,j)-1; 
				w_sum_j(j)=w_sum_j(j)+(1-b(k,j))*y_sum_kjl(k,j,j);
			end			
			numcj(j)=numcj(j)+b(k,j);
			if numcj(j)<0
				display 'negative numcj'
				numcj
				keyboard;
			end
			numwj(j)=numwj(j)+(1-b(k,j)).*numk(k);
			if numwj(j)<0
				display 'negative numwj'
				numwj
				keyboard;
			end
		end
	end
	b_out=b;
	numcj_out=numcj;
	numwj_out=numwj;
	w_sum_j_out=w_sum_j;
	%b
	%[squeeze(Y(target,:,:)) data(target,:)']
	%if Z(target) > 0
	%	Z(target)	
	%	b(Z(target),:)
	%end


end

function   [Y_out,y_sum_kjl_out y_prod_kjl_out,lambdaAll_out]= sample_yjl_fast_collapsed(t,j,l,Z,numk,data,Y,y_sum_kjl,y_prod_kjl,ajl,bjl,lambdaAll,logtable)

	yjl=0;
	M=size(data,2);
	k=Z(t);
	yjl_old=Y(t,j,l);
	yjj_old=Y(t,j,j);
	yll_old=Y(t,l,l);
	y_sum_kjl(k,j,l)=y_sum_kjl(k,j,l)-yjl_old;
	y_sum_kjl(k,j,j)=y_sum_kjl(k,j,j)-yjj_old;
	y_sum_kjl(k,l,l)=y_sum_kjl(k,l,l)-yll_old;
	y_prod_kjl(k,j,l)=y_prod_kjl(k,j,l)-gammaln(yjl_old+1);
	y_prod_kjl(k,j,j)=y_prod_kjl(k,j,j)-gammaln(yjj_old+1);
	y_prod_kjl(k,l,l)=y_prod_kjl(k,l,l)-gammaln(yll_old+1);

        t1=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M))+Y(t,j,l);
        t2=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M))+Y(t,j,l);
	yjl_range=min(t1,t2);
	p=zeros(1,yjl_range+1);
    
	if lambdaAll(Z(t),j,l)==0 yjl=0; 
	else

		%initialization phase
		yjj=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M))-yjl+Y(t,j,l);
		yll=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M))-yjl+Y(t,j,l);

		tjl_term1=y_sum_kjl(Z(t),j,l)+ajl(j,l)+yjl;
		tjj_term1=y_sum_kjl(Z(t),j,j)+ajl(j,j)+yjj;
		tll_term1=y_sum_kjl(Z(t),l,l)+ajl(l,l)+yll;

		tjl=gammaln(y_sum_kjl(Z(t),j,l)+ajl(j,l)+yjl)-(y_sum_kjl(Z(t),j,l)+ajl(j,l)+yjl) * log(numk(Z(t))+bjl(j,l))-gammaln(yjl+1);
		tjj=gammaln(y_sum_kjl(Z(t),j,j)+ajl(j,j)+yjj)-(y_sum_kjl(Z(t),j,j)+ajl(j,j)+yjj) * log(numk(Z(t))+bjl(j,j))-gammaln(yjj+1);
		tll=gammaln(y_sum_kjl(Z(t),l,l)+ajl(l,l)+yll)-(y_sum_kjl(Z(t),l,l)+ajl(l,l)+yll) * log(numk(Z(t))+bjl(l,l))-gammaln(yll+1);
		p(1,1)=tjl+tjj+tll;

		const1=log(numk(Z(t))+bjl(j,l));

		%iterative updates
		for yjl=1:yjl_range
			yjj=yjj-1;
			yll=yll-1;

			p(1,yjl+1)=p(1,yjl)+log(tjl_term1)-const1-logtable(yjl);
			tjl_term1=tjl_term1+1;
			tjj_term1=tjj_term1-1;
			tll_term1=tll_term1-1;
				p(1,yjl+1)=p(1,yjl+1)-log(tjj_term1)+const1+log(yjj);
				p(1,yjl+1)=p(1,yjl+1)-log(tll_term1)+const1+log(yll);
    		end	
      
		if size(p,2)>0  yjl=sampleLogMultFast(p); yjl=yjl-1; else yjl=0; end
	end

	Y(t,j,l)=yjl;
	Y(t,j,j)=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M));
	Y(t,l,l)=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M));
	y_sum_kjl(k,j,l)=y_sum_kjl(k,j,l)+yjl;
	y_sum_kjl(k,j,j)=y_sum_kjl(k,j,j)+Y(t,j,j);
	y_sum_kjl(k,l,l)=y_sum_kjl(k,l,l)+Y(t,l,l);
	y_prod_kjl(k,j,l)=y_prod_kjl(k,j,l)+gammaln(yjl_old+1);
	y_prod_kjl(k,j,j)=y_prod_kjl(k,j,j)+gammaln(yjj_old+1);
	y_prod_kjl(k,l,l)=y_prod_kjl(k,l,l)+gammaln(yll_old+1);

	if y_sum_kjl(k,j,j)<0 || y_sum_kjl(k,l,l)<0 || y_sum_kjl(k,j,l)<0 
		display(sprintf('alert ysum %d %d %d = %d %d %d,   t1=%d t2=%d',k,j,l,y_sum_kjl(k,j,j), y_sum_kjl(k,l,l),y_sum_kjl(k,j,l),t1,t2));
	end

    
    Y_out=Y;
    y_sum_kjl_out=y_sum_kjl;
    y_prod_kjl_out=y_prod_kjl;
    lambdaAll_out=lambdaAll;
end


function [numk_o numkl_o K_o y_sum_kjl_o y_prod_kjl_o,beta_o mcount_o Z_o,lambdaAll_o,lambda_o, b_o,numcj_o , w_sum_j_o]=addcompact(t,z_new,z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,y_sum_kjl,y_prod_kjl,Z,lambdaAll,lambda,b,numcj,w_sum_j)

	if z_new>K
		K=K+1;
		numk(z_new)=1;
		numk(z_new+1)=0;
		numkl(z_new+1,:)=0;
		numkl(:,z_new+1)=0;   

		if z_prev ~= -1         numkl(z_prev,z_new)=1;  end
		if z_next ~=-1		numkl(z_new,z_next)=1;  end   
		y_sum_kjl(z_new+1,:,:)=0;
		y_prod_kjl(z_new+1,:,:)=0;
		w_sum_kjl(z_new+1,:)=0;
		if z_old ==-1
			b(z_new,:)=1;
		else 
			b(z_new,:)=1;
		end
		mcount(K+1)=mcount(K);
		b(z_new+1,:)=1;
		mcount(K)=1;
		beta=sample_beta(mcount);
		numcj=numcj+b(z_new,:);

	else 
		numk(z_new)=numk(z_new)+1;
		if z_prev ~= -1 		numkl(z_prev,z_new)=numkl(z_prev,z_new)+1; end
		if z_next ~= -1 		numkl(z_new,z_next)=numkl(z_new,z_next)+1; end
        end
	   delind=find(numk(1:K)==0);
	   numRemove=size(delind,2);
	   if numRemove > 0

		   %change cluster indices
		   for d=1:numRemove
			   kdel=delind(d);

			   templist=find(Z>kdel);
			   Z(templist)=Z(templist)-1;

			   templist=find(delind>kdel);
			   delind(templist)=delind(templist)-1;
		end

		numcj=numcj-sum(b(delind,:),1);
		K=K-size(delind,2);
		numk(delind)=[];
		numkl(delind,:)=[];
		numkl(:,delind)=[];
		y_sum_kjl(delind,:,:)=[];
		y_prod_kjl(delind,:,:)=[];
		beta(delind)=[];
		mcount(delind)=[];
		b(delind,:)=[];
		lambdaAll(delind,:,:)=[];
		lambda(delind,:)=[];
	end


	numk_o=numk;
	numkl_o=numkl;
	K_o=K;
	Z_o=Z;
	y_sum_kjl_o=y_sum_kjl; 
	y_prod_kjl_o=y_prod_kjl; 
	beta_o=beta;
	mcount_o=mcount;
	lambdaAll_o=lambdaAll;
	lambda_o=lambda;
	b_o=b;
	numcj_o=numcj;
	w_sum_j_o=w_sum_j;

end

function r = drchrnd(a,n)
p = length(a);
r = gamrnd(repmat(a,n,1),1,n,p);
r = r ./ repmat(sum(r,2),1,p);
end

function z=sampleLogMultFast(p)
	mp=max(p);
	p(:,:)=p(:,:)-mp;
	p=exp(p);
	
	p=p/sum(p);
	z=find(mnrnd(1,p)>0);
end
function z=sampleLogMult(p)
	N=size(p,2);
	p1=zeros(1,N);
	for k=1:N
		sump=0;
		for l=1:N
			sump=sump+exp(p(1,l)-p(1,k));
		end
		p1(1,k)=1/sump;
	end
	p=p1;

	z=find(sample_hist(p',1)>0);
end

function [vec]=normalize(vec)
sumv=sum(vec);
vec=vec./sumv;
end

function ll=llikelihood(data,Z,lambda,b)
VERY_SMALL_NUMBER=0.000001;
VERY_SMALL_LOG=-1000000000;
ll=0;
[T,M]=size(data);
K=max(Z);
for i=1:M

	for k=1:K
			dtemp=0;
			ztemp=0;
			ltemp=0;
			for t=1:T
				dtemp=dtemp+(Z(t)==k)*data(t,i);				
				ztemp=ztemp+(Z(t)==k);
			end
			if lambda(k,i)>VERY_SMALL_NUMBER
				ll=ll+dtemp*log(lambda(k,i))-lambda(k,i)*ztemp;
			else
				ll=ll+dtemp*VERY_SMALL_LOG-lambda(k,i)*ztemp;
			end
			if isnan(ll)
				display(sprintf('%d %f \n',dtemp,lambda(k,i)));
			end
			
	end
		for t=1:T
			%gammaln (x+1) is a substitute for logfactorial x
			ll=ll-gammaln(data(t,i)+1);
		end
	end
end


function logtable=createlogtable(data)
N=max(max(data))*20;
logtable=zeros(1,N);
for i =1:N
		logtable(i)=log(i);
	end
end

function T = tridiag(a, b, c, n)
T = b*diag(ones(n,1)) + c*diag(ones(n-1,1),1) + a*diag(ones(n-1,1),-1);
end


%A quick implementation of viterbi algorithm for state decoding%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function p=logemissionIP(X,lambda)
p=0;
M=size(X,2);
for i=1:M
		p=p+log(lambda(i))-gammaln(X(i)+1)-lambda(i);
	end
end

function [Z]=hdphmm_viterbi(data,model)
lambda=model.lambda;
pkl=model.pkl;
pk=model.pk;
[T M]=size(data);
K=size(lambda,1);
Z=zeros(1,T);
obj=zeros(T,K);	

for k=1:K
		obj(1,k)=log(pk(k))+logemissionIP(data(1,:),lambda(k,:));
		path(1,k)=0;
	end

	for t=2:T
		for l=1:K
			[obj(t,l) path(t,l)]=max(obj(t-1,:)'+log(pkl(:,l)));
			obj(t,l)=logemissionIP(data(t,:),lambda(l,:))+obj(t,l);
		end

	end
	[m Z(T)]=max(obj(T,:));
	for t=T-1:-1:1
		Z(t)=path(t+1,Z(t+1));
	end
	Z'
end

function res=logWeightedAverage(la,lb,x,y)
	if x==0
		res=lb;
	elseif y==0
		res=la;
	else
		res1=exp(lb-la+log(y/x));
		if isinf(res1)
			res=(la+log(x)-log(x+y))+lb-la+log(y/x);
		else	
			res=(la+log(x)-log(x+y))+log(1+exp(lb-la+log(y/x)));
		end
	end
end
				

function b_post=get_b_posterior(b,ab,bb,numcj,K)
		b_post=prod(((ab(:)+numcj(:)-1)'.^b(1,:)+(bb(:)+K-numcj(:))'.^(1-b(1,:)))./(ab(:)+bb(:)+K)');
end
function [b_new pr numSamples]=generateMHSample(b_old,eta,ab,bb,numcj,K)
	a=0;
	%display('attempt mh sample');
	b_new=b_old;
	M=size(b_old,2);
	numSamples=0;
	while a<1
		%pr=zeros(1,M);
		b_new=b_old;
		for j=1:M
			if rand()<eta
				b_new(1,j)=1-b_old(1,j);
			end
		end		
		pr=get_b_posterior(b_new,ab,bb,numcj,K)/get_b_posterior(b_old,ab,bb,numcj,K);
		%pr=prod(((ab(:)+numcj(:)-1)'.^b_new(1,:)+(bb(:)+K-numcj(:))'.^(1-b_new(1,:)))./(ab(:)+bb(:)+K)');
		a=min(1, pr);
		numSamples=numSamples+1;
		if rand()<a
			return;
		end

		if mod(numSamples ,100)==0
			display(sprintf('%d samples %f ',numSamples,a));
		end
		if numSamples>15
			b_new=b_old;
			return;
		end

	end
end
