function [Z lambda ll pkl beta model]= mvp_hdphmm(datafile,maxIter,outfile,trmodel,tridia,param_a)
	%Input : can pass either data file or data array and number of iterations
	%data expected - matrix -  rows increasing along time and columns are features 
	%parameters - for now, no hyper parameter sampling
	%The last argument specifies if it is a tridiagonal covariance
	al=1;bl=1;    %hyper parameters of lambda the emissionCollapsed parameter that is integrated out
	alpha=1;gamma=1;

	if ~exist('tridia') || isempty(tridia)
		tridia=0;
	end


	%From MVP code 
	global VERY_SMALL_LOG;
	VERY_SMALL_LOG=-1000000000;
	VERY_SMALL_NUMBER=0.00000001;
	%what we got with this file
	rng(2);
	randomseed([3 4 5]);

	if isempty(maxIter) maxIter=100; 
	end %number of gibbs iterations
	display(sprintf('Maximum gibbs iter = %d',maxIter));

	if isempty(outfile)
		outfile='res_mvp_hdphmm.mat';
	end

	data=[];
	if ischar(datafile) data=csvread(datafile);
	else data=datafile;
	end

	global logtable;
	logtable=createlogtable(data);


	data=data ;
	[T M]=size(data)
	K=0;
	%data([14000:15000,1:20])
	ajl=zeros(M,M); ajl(:,:)=al;
	bjl=zeros(M,M); bjl(:,:)=bl;

	gammalnajl=gammaln(ajl(:,:));
	gammalnbjl=gammaln(bjl(:,:));
	lambdaAll=zeros(K+1,M,M);
	lambda=[];
	if ~exist('param_a')
		ajl=100*ones(M,M);
	else  
		ajl=param_a*ones(M,M);
	end 
	%ajl=eye(M,M);
	bjl=ones(M,M);
	%ajl=sqrt(ones(M,M).*mean(data(find(data>=0))));
	if tridia
		ajl = eye(M);
		%ajl = tridiag(1,1,1,M);
	end

	global mask;
	mask=ajl(:,:)>0;
	for j=1:M
		for l=1:M
			if j>l mask(j,l)=0; end
		end
	end

	%data([14000:15000,1:20])

	%Random variables to be sampled
	Z=ones(1,T);
	Z(:,:)=-1;
	Y=zeros(T,M,M);%We have declared a full matrix here though it is required to have only m*(m+1)/2 items.
	for t=1:T
		for j=1:M
			Y(t,j,j)=diag(data(t,j));
       		end
	end


	mcount=size(1,K+1);
	beta=ones(1,K+1);

	mcount(1)=1;mcount(2)=gamma;
	beta(K+1)=alpha;
	beta=normalize(beta);
	%Initialize with 0 topics
	numk=zeros(1,K+1);
	numkl=zeros(K+1,K+1);
	%y_sum_ki=zeros(K+1,M);
	y_sum_kjl=zeros(K+1,M,M);
	mcount(1)=gamma;
	beta(1)=1;

	if exist('trmodel') && ~isempty(trmodel)
		mcount=trmodel.mcount;
		numkl=trmodel.numkl;
		numk=trmodel.numk;
		y_sum_kjl=trmodel.y_sum_kjl;
		beta=trmodel.beta;
		mask=trmodel.mask;
		lambda=trmodel.lambda;
		lambdaAll=trmodel.lambdaAll;
		alpha=trmodel.alpha;
		gamma=trmodel.gamma;
		al=trmodel.al;
		bl=trmodel.bl;
		gammalnajl=trmodel.gammalnajl;
		gammalnbjl=trmodel.gammalnbjl;
		mask=trmodel.mask;
		ajl=trmodel.ajl;
		bjl=trmodel.bjl;
		K=trmodel.K;
	end

	total_timerval=tic;
	iter_time_arr=[];
	tic;
	Z_old=Z;
	perp=0;
	%Actually sampling
	for iter=1:maxIter
	        display(sprintf('mvp_hdphmm Gibbs iter %d/%d, K=%d\n',iter,maxIter,K));
		iter_time=tic;
		tic;
	        for t=1:T
			  if ~mod(t,200) 
				  toc
				  display(sprintf('mvp_hdphmm Gibbs iter iter=%d t= %d/%d K=%d\n',iter,t,T,K));  
				  tic
	     	    		  %ll=llikelihood(data(:,:),Z,lambda);
		    	  end
		    z_old=Z(t);
		    if t>1  z_prev=Z(t-1); else z_prev=-1; 
		    end
		    if t<T && iter~=1  z_next=Z(t+1); else z_next=-1; 
		    end
		    if iter~=1
			    [numk numkl  K y_sum_kjl beta mcount]=remove(t,z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,y_sum_kjl);
	    	    end
		    [Z(t) y_sum_kjl lambdaAll]= sample_z_collapsed(t,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,ajl,bjl,lambdaAll);

		    [numk numkl K y_sum_kjl beta mcount Z lambdaAll lambda]=addcompact(t,Z(t),z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,y_sum_kjl,Z,lambdaAll,lambda);

        	    for j=1:M
                    	   for l=1:M
        	                  if(j<l)&&ajl(j,l)~=0  [Y y_sum_kjl,lambdaAll]= sample_yjl_fast_collapsed(t,j,l,Z,numk,data,Y,y_sum_kjl,ajl,bjl,lambdaAll,logtable);
	            	   	  end
		    	   end
        	    end
			
	      end
	      toc;
	     Z_old=Z;
	     display(sprintf('gibbs iter %d %d \n',iter,t));
	     %numk
	     mcount=sample_m(beta,numk,alpha,gamma,K); 
	     beta=sample_beta(mcount);

	     %lambda_old=lambda;
	     [lambda lambdaAll]=sampleLambdaAll(Z,data,ajl,bjl,Y,K,y_sum_kjl,numk);

	     [ll perp]=llikelihood(data(:,:),Z,lambda);
	     model.lambda=lambda;
	     model.Z=Z;
	     model.iter_time_arr=iter_time_arr;
	     model.mcount=mcount;;
             model.numkl=numkl;;
	     model.numk=numk;;
	     model.y_sum_kjl=y_sum_kjl;
	     model.beta=beta;
	     model.mask=mask;
	     model.lambda=lambda;
	     model.lambdaAll=lambdaAll;
	     model.alpha=alpha;
	     model.gamma=gamma;
	     model.al=al;
	     model.bl=bl;
	     model.gammalnajl=gammalnajl;
	     model.gammalnbjl=gammalnbjl;
	     model.ajl=ajl;
	     model.bjl=bjl;
	     model.K=K;
	     model.perp=perp;
	     model.ll=ll;
	     save(outfile,'-struct','model');
	     display(sprintf('likelihood = %f with K=%d\n',ll,K));
	     iter_time_arr(iter)=toc(iter_time);
       	end
        total_elapsed_time=toc(total_timerval);;

	%Find transition probabilities
	pkl=zeros(K,K);
	%numkl
	for k=1:K
	  pkl(k,:)=numkl(k,1:K)./sum(numkl(k,1:K));
	end
	pk=numk(1:K)/sum(numk(1:K));

	%Find mean parameter
	%lambda=meanEmissionParam(Z,data,al,bl,K);
	[lambda lambdaAll]=sampleLambdaAll(Z,data,ajl,bjl,Y,K,y_sum_kjl,numk);



	model.mcount=mcount;;
	model.numkl=numkl;;
	model.numk=numk;;
	model.y_sum_kjl=y_sum_kjl;
	model.beta=beta;
	model.mask=mask;
	model.lambda=lambda;
	model.lambdaAll=lambdaAll;
	model.alpha=alpha;
	model.gamma=gamma;
	model.al=al;
	model.bl=bl;
	model.gammalnajl=gammalnajl;
	model.gammalnbjl=gammalnbjl;
	model.ajl=ajl;
	model.bjl=bjl;
	model.K=K;
	model.perp=perp;
	model.total_elapsed_time=total_elapsed_time;
	model.iter_time_arr=iter_time_arr;

	model.pkl=pkl;
	model.pk=pk;
	model.Z=Z;
	model.ll=ll;
	model.tridia=tridia;
	if exist('trmodel') && ~isempty(trmodel)  model.trainll=trmodel.ll; end

	%Now estimate the state sequence Z using the viterbi algorithm to get a proper estimate of the state sequence
	%Z=hdphmm_viterbi(data,model);
	model.Z=Z;

	save(outfile,'-struct','model');
	Z=Z'; 
	if exist('trmodel') && ~isempty(trmodel)
		display(sprintf('obtained %d clusters with Train likelihood =%f',trmodel.K,model.trainll));
	end
	display(sprintf('obtained %d clusters with likelihood=%f, perplexity=%f',size(lambda,1),ll,perp));


end

function [z y_sum_kjl_out lambdaAll_out]=sample_z_collapsed(t,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,ajl,bjl,lambdaAll)
	VERY_SMALL_LOG=-1000000000;
	VERY_SMALL_NUMBER=0.00000001;
	z_old=Z(t);
	[T M]=size(data);
	%if  Z(t)>0 y_sum_kjl(z_old,:,:)=y_sum_kjl(z_old,:,:)-Y(t,:,:); end
	p=zeros(1,K+1);
	for k=1:K+1
		term_prev=1; if t>1 term_prev=(numkl(Z(t-1),k)+alpha*beta(k)); end
		term_next=1; if (t<size(data,1) && Z(t+1)~=-1)  term_next = (numkl(k,Z(t+1))+alpha*beta(Z(t+1)))/ (numk(k)+alpha) ; end
		emis=VERY_SMALL_LOG;
		emis=logemissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl);

	   	 %emis=  logemissionCollapsed(t,k,Z,numk,data,y_sum_ki,al,bl); %From HDPHMM
	    	p(1,k)=log(term_prev)+log(term_next)+emis;
	    	if isnan(p(1,k))
		    display(sprintf('k=%d termprev %f termnext %f emis %f p(1,k) %f \n',k,term_prev,term_next,emis,p(1,k)));
		    keyboard
	    	end
	end	

	z=sampleLogMult(p);

	if z==K+1
		y_sum_kjl(z,:,:)=Y(t,:,:);
		for j=1:M 
			for l=1:M
				if j>l continue; end
					if ajl~=0 	lambdaAll(z,j,l)=gamrnd(y_sum_kjl(z,j,l)+ajl(j,l),1/(bjl(j,l)+1)); end
					end 
		end
		lambdaAll(z+1,:,:)=0;

	else    y_sum_kjl(z,:,:)=y_sum_kjl(z,:,:)+Y(t,:,:);		
	end
	y_sum_kjl_out=y_sum_kjl;
	lambdaAll_out=lambdaAll;
end

function [z y_sum_kjl_out lambdaAll_out]=sample_z(t,Z,numkl,numk,K,alpha,beta,data,Y,y_sum_kjl,ajl,bjl,lambdaAll)
	VERY_SMALL_LOG=-1000000000;
	VERY_SMALL_NUMBER=0.00000001;
	z_old=Z(t);
	[T M]=size(data);
	%if  Z(t)>0 y_sum_kjl(z_old,:,:)=y_sum_kjl(z_old,:,:)-Y(t,:,:); end
	p=zeros(1,K+1);
	for k=1:K+1
		term_prev=1; if t>1 term_prev=(numkl(Z(t-1),k)+alpha*beta(k)); end
		term_next=1; if (t<size(data,1) && Z(t+1)~=-1)  term_next = (numkl(k,Z(t+1))+alpha*beta(Z(t+1)))/ (numk(k)+alpha) ; end
		emis=VERY_SMALL_LOG;
		if k<K+1
			emis=logemissionMVP(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl,lambdaAll);
	        else
		    emis=0;
		    %emis=VERY_SMALL_LOG;
		    for j=1:M
			    for l=1:M
				    if j>l continue; end
				    if ajl(j,l)~=0
					    emis=emis+gammaln(Y(t,j,l)+ajl(j,l))-gammaln(ajl(j,l))+ajl(j,l).* log(bjl(j,l))-(Y(t,j,l)+ajl(j,l)).*log(bjl(j,l)+1)-gammaln(Y(t,j,l)+1);
			    	    end
		    	   end
	            end
               end

	    p(1,k)=log(term_prev)+log(term_next)+emis;
	    if isnan(p(1,k))
		    display(sprintf('k=%d termprev %f termnext %f emis %f p(1,k) %f \n',k,term_prev,term_next,emis,p(1,k)));
		    keyboard
	    end
	end	

	z=sampleLogMult(p);

	if z==K+1
		y_sum_kjl(z,:,:)=Y(t,:,:);
		for j=1:M 
			for l=1:M
				if j>l continue; end
					if ajl~=0 	lambdaAll(z,j,l)=gamrnd(y_sum_kjl(z,j,l)+ajl(j,l),1/(bjl(j,l)+1)); end
					end 
		end
		lambdaAll(z+1,:,:)=0;

	else    y_sum_kjl(z,:,:)=y_sum_kjl(z,:,:)+Y(t,:,:);		
	end
	y_sum_kjl_out=y_sum_kjl;
	lambdaAll_out=lambdaAll;
end

function [beta]=sample_beta(mcount)
beta=drchrnd(mcount,1);
end

function [mcount]=sample_m(beta,numk,alpha,gamma,K)
mcount=zeros(1,K+1);
for k=1:K
		tot=numk(k);
		totsofar=0;
		for c=1:tot
			x=alpha*beta(k)/(alpha*beta(k)+totsofar);
			totsofar=totsofar+1;
			if rand()<x
				mcount(k)=mcount(k)+1;
			end
		end
	end
	mcount(K+1)=gamma;
end

function [em]=emissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl)
  em=exp(logemission(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl));
end

%This function is the slowest link. 
function [em]=logemissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl)
	%display('emission');
	global mask;
	global logtable;
	%[T M]=size(data);
	%res=0;
	tmp(:,:)= - (permute(y_sum_kjl(k,:,:)+Y(t,:,:),[2,3,1])+ajl(:,:)) .* logtable(numk(k)+1+bjl(:,:)) +(permute(y_sum_kjl(k,:,:),[2 3 1])+ajl(:,:)) .* logtable(numk(k)+bjl(:,:)) -gammaln(permute(y_sum_kjl(k,:,:),[2 3 1])+ajl(:,:)) +gammaln(permute(y_sum_kjl(k,:,:)+Y(t,:,:),[2 3 1])+ajl(:,:)) -gammaln(permute(Y(t,:,:),[2 3 1])+1) ;	
	tmp(find(isnan(tmp)))=0;
	res(:,:)=sum(sum(tmp.*mask));
	em=res;
end

function [em]=logemissionMVP(t,k,Z,numk,data,Y,y_sum_kjl,ajl,bjl,lambdaAll)
VERY_SMALL_LOG=-1000000000;
VERY_SMALL_NUMBER=0.00000001;
%display('emission');
[T M]=size(data);
res=0;
for j=1:M
		for l=1:M
			if j>l continue; end
				%the first gammaln is a replacement for logfactorial of one number lower
				if lambdaAll(k,j,l)>VERY_SMALL_NUMBER
					res=res+Y(t,j,l)*log(lambdaAll(k,j,l))-lambdaAll(k,j,l)-gammaln(Y(t,j,l)+1) ;
			elseif Y(t,j,l)~=0
				res=res+VERY_SMALL_LOG;
			end
			%display(sprintf('iteration t=%d i=%d k=%d\n',t,i,k));
	       end
      end
      em=res;
end

function [lambda lambdaAll]=sampleLambdaAll(Z,data,ajl,bjl,Y,K,y_sum_kjl,numk)
	[T,M]=size(data);
	lambdaAll=zeros(K+1,M,M);
	lambda=zeros(K,M);
	for k=1:K
		for j=1:M
			for l=1:M
				if j>l continue; end
				if ajl(j,l)>0
					lambdaAll(k,j,l)=gamrnd(y_sum_kjl(k,j,l)+ajl(j,l),1/(bjl(j,l)+numk(k)));
				else
					lambdaAll(k,j,l)=0;
				end
			end
		end
		for j=1:M
			lambda(k,j)=sum(lambdaAll(k,1:j-1,j))+sum(lambdaAll(k,j,j:M));
		end		
	end
			
end


%z_prev is z_t-1
function [numk_o numkl_o K_o y_sum_kjl_o beta_o mcount_o]=remove(t,z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,y_sum_kjl)
	%numkl %dbg
	%numk %dbg
	numk(z_old)=numk(z_old)-1; 
	if z_prev ~= -1              numkl(z_prev,z_old)=numkl(z_prev,z_old)-1;  end
	if z_next ~= -1   		numkl(z_old,z_next)=numkl(z_old,z_next)-1;  end
	%numkl %dbg
	%numk %dbg
	for j=1:M 
		for l=1:M 
			if j>l continue; end 
			y_sum_kjl(z_old,j,l)=y_sum_kjl(z_old,j,l)-Y(t,j,l);
			if y_sum_kjl(z_old,j,l)<0
				display(sprintf('caught ya!! %d %d %d  Y(t,j,l)=%d y_sum_kjl(z_old,j,l)=%d\n',z_old,j,l,Y(t,j,l),y_sum_kjl(z_old,j,l)+Y(t,j,l)));
				%keyboard;
			end
		end
	end

	numk_o=numk;
	numkl_o=numkl;
	K_o=K;
	y_sum_kjl_o=y_sum_kjl; 
	beta_o=beta;
	mcount_o=mcount;

end


function   [Y_out,y_sum_kjl_out lambdaAll_out]= sample_yjl_fast(t,j,l,Z,numk,data,Y,y_sum_kjl,ajl,bjl,lambdaAll,logtable)


	yjl=0;
	M=size(data,2);
	k=Z(t);
	yjl_old=Y(t,j,l);
	yjj_old=Y(t,j,j);
	yll_old=Y(t,l,l);
	y_sum_kjl(k,j,l)=y_sum_kjl(k,j,l)-yjl_old;
	y_sum_kjl(k,j,j)=y_sum_kjl(k,j,j)-yjj_old;
	y_sum_kjl(k,l,l)=y_sum_kjl(k,l,l)-yll_old;

        t1=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M))+Y(t,j,l);
        t2=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M))+Y(t,j,l);
	yjl_range=min(t1,t2);
	p=zeros(1,yjl_range+1);
    
	if lambdaAll(Z(t),j,l)==0 yjl=0; 
	else

		yjj=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M))-yjl+Y(t,j,l);
		yll=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M))-yjl+Y(t,j,l);

		tjl=yjl*log(lambdaAll(Z(t),j,l))-lambdaAll(Z(t),j,l)-gammaln(yjl+1);
		tjj=yjj*log(lambdaAll(Z(t),j,j))-lambdaAll(Z(t),j,j)-gammaln(yjj+1);
		tll=yll*log(lambdaAll(Z(t),l,l))-lambdaAll(Z(t),l,l)-gammaln(yll+1);
		p(1,1)=tjl+tjj+tll;

		ltjl=log(lambdaAll(Z(t),j,l));
		ltjj=log(lambdaAll(Z(t),j,j));
		ltll=log(lambdaAll(Z(t),l,l));

		for yjl=1:yjl_range
		
			tjl=tjl+ltjl-logtable(yjl+1);
			tjj=tjj-ltjj+logtable(yjj-yjl+2);
			tll=tll-ltll+logtable(yll-yjl+2);

			p(1,yjl+1)=tjl+tjj+tll;
    		end	
       
		if size(p,2)>0  yjl=sampleLogMult(p); yjl=yjl-1; else yjl=0; end
	end

	Y(t,j,l)=yjl;
	Y(t,j,j)=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M));
	Y(t,l,l)=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M));
	y_sum_kjl(k,j,l)=y_sum_kjl(k,j,l)+yjl;
	y_sum_kjl(k,j,j)=y_sum_kjl(k,j,j)+Y(t,j,j);
	y_sum_kjl(k,l,l)=y_sum_kjl(k,l,l)+Y(t,l,l);

	if y_sum_kjl(k,j,j)<0 || y_sum_kjl(k,l,l)<0 || y_sum_kjl(k,j,l)<0 
		display(sprintf('alert ysum %d %d %d = %d %d %d,   t1=%d t2=%d',k,j,l,y_sum_kjl(k,j,j), y_sum_kjl(k,l,l),y_sum_kjl(k,j,l),t1,t2));
	end

    Y_out=Y;
    y_sum_kjl_out=y_sum_kjl;
    lambdaAll_out=lambdaAll;
        %p=p./sum(p);
    	%z=find(mnrnd(1,p)>0);	
end


function   [Y_out,y_sum_kjl_out lambdaAll_out]= sample_yjl_fast_collapsed(t,j,l,Z,numk,data,Y,y_sum_kjl,ajl,bjl,lambdaAll,logtable)

	yjl=0;
	M=size(data,2);
	k=Z(t);
	yjl_old=Y(t,j,l);
	yjj_old=Y(t,j,j);
	yll_old=Y(t,l,l);
	y_sum_kjl(k,j,l)=y_sum_kjl(k,j,l)-yjl_old;
	y_sum_kjl(k,j,j)=y_sum_kjl(k,j,j)-yjj_old;
	y_sum_kjl(k,l,l)=y_sum_kjl(k,l,l)-yll_old;

        t1=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M))+Y(t,j,l);
        t2=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M))+Y(t,j,l);
	yjl_range=min(t1,t2);
	p=zeros(1,yjl_range+1);
    
	if lambdaAll(Z(t),j,l)==0 yjl=0; 
	else

		%initialization phase
		yjj=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M))-yjl+Y(t,j,l);
		yll=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M))-yjl+Y(t,j,l);

		tjl_term1=y_sum_kjl(Z(t),j,l)+ajl(j,l)+yjl;
		tjj_term1=y_sum_kjl(Z(t),j,j)+ajl(j,j)+yjj;
		tll_term1=y_sum_kjl(Z(t),l,l)+ajl(l,l)+yll;

		tjl=gammaln(y_sum_kjl(Z(t),j,l)+ajl(j,l)+yjl)-(y_sum_kjl(Z(t),j,l)+ajl(j,l)+yjl) * log(numk(Z(t))+bjl(j,l))-gammaln(yjl+1);
		tjj=gammaln(y_sum_kjl(Z(t),j,j)+ajl(j,j)+yjj)-(y_sum_kjl(Z(t),j,j)+ajl(j,j)+yjj) * log(numk(Z(t))+bjl(j,j))-gammaln(yjj+1);
		tll=gammaln(y_sum_kjl(Z(t),l,l)+ajl(l,l)+yll)-(y_sum_kjl(Z(t),l,l)+ajl(l,l)+yll) * log(numk(Z(t))+bjl(l,l))-gammaln(yll+1);
		p(1,1)=tjl+tjj+tll;

		const1=log(numk(Z(t))+bjl(j,l));

		%iterative updates
		for yjl=1:yjl_range
			yjj=yjj-1;
			yll=yll-1;

			p(1,yjl+1)=p(1,yjl)+log(tjl_term1)-const1-logtable(yjl);
			tjl_term1=tjl_term1+1;
			tjj_term1=tjj_term1-1;
			tll_term1=tll_term1-1;
				p(1,yjl+1)=p(1,yjl+1)-log(tjj_term1)+const1+log(yjj);
				p(1,yjl+1)=p(1,yjl+1)-log(tll_term1)+const1+log(yll);
		
    		end	
      
		if size(p,2)>0  yjl=sampleLogMultFast(p); yjl=yjl-1; else yjl=0; end
	end

	Y(t,j,l)=yjl;
	Y(t,j,j)=data(t,j)-sum(Y(t,1:j-1,j))-sum(Y(t,j,j+1:M));
	Y(t,l,l)=data(t,l)-sum(Y(t,1:l-1,l))-sum(Y(t,l,l+1:M));
	y_sum_kjl(k,j,l)=y_sum_kjl(k,j,l)+yjl;
	y_sum_kjl(k,j,j)=y_sum_kjl(k,j,j)+Y(t,j,j);
	y_sum_kjl(k,l,l)=y_sum_kjl(k,l,l)+Y(t,l,l);

	if y_sum_kjl(k,j,j)<0 || y_sum_kjl(k,l,l)<0 || y_sum_kjl(k,j,l)<0 
		display(sprintf('alert ysum %d %d %d = %d %d %d,   t1=%d t2=%d',k,j,l,y_sum_kjl(k,j,j), y_sum_kjl(k,l,l),y_sum_kjl(k,j,l),t1,t2));
	end

    Y_out=Y;
    y_sum_kjl_out=y_sum_kjl;
    lambdaAll_out=lambdaAll;
end


function [numk_o numkl_o K_o y_sum_kjl_o beta_o mcount_o Z_o,lambdaAll_o,lambda_o]=addcompact(t,z_new,z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,y_sum_kjl,Z,lambdaAll,lambda)

	if z_new>K
		K=K+1;
		numk(z_new)=1;
		numk(z_new+1)=0;
		numkl(z_new+1,:)=0;
		numkl(:,z_new+1)=0;   

		if z_prev ~= -1         numkl(z_prev,z_new)=1;  end
		if z_next ~=-1		numkl(z_new,z_next)=1;  end   
		y_sum_kjl(z_new+1,:,:)=0;
		%y_sum_ki(z_new+1,i)=0;
		mcount(K+1)=mcount(K);
		mcount(K)=1;
		beta=sample_beta(mcount);

	else 
		numk(z_new)=numk(z_new)+1;
		if z_prev ~= -1 		numkl(z_prev,z_new)=numkl(z_prev,z_new)+1; end
		if z_next ~= -1 		numkl(z_new,z_next)=numkl(z_new,z_next)+1; end
		%y_sum_kjl(z_new,:,:)=y_sum_kjl(z_new,:,:)+Y(t,:,:); This is taken care of during sampling I presume
        end
	   delind=find(numk(1:K)==0);
	   numRemove=size(delind,2);
	   if numRemove > 0
		   %change cluster indices
		   for d=1:numRemove
			   kdel=delind(d);

			   templist=find(Z>kdel);
			   Z(templist)=Z(templist)-1;

			   templist=find(delind>kdel);
			   delind(templist)=delind(templist)-1;
		end
		%Z %dbg

		K=K-size(delind,2);
		numk(delind)=[];
		numkl(delind,:)=[];
		numkl(:,delind)=[];
		y_sum_kjl(delind,:,:)=[];
		beta(delind)=[];
		mcount(delind)=[];
		lambdaAll(delind,:,:)=[];
		lambda(delind,:)=[];
	end


	numk_o=numk;
	numkl_o=numkl;
	K_o=K;
	Z_o=Z;
	y_sum_kjl_o=y_sum_kjl; 
	beta_o=beta;
	mcount_o=mcount;
	lambdaAll_o=lambdaAll;
	lambda_o=lambda;

end

function r = drchrnd(a,n)
p = length(a);
r = gamrnd(repmat(a,n,1),1,n,p);
r = r ./ repmat(sum(r,2),1,p);
end

function z=sampleLogMultFast(p)
	mp=max(p);
	p(:,:)=p(:,:)-mp;
	p=exp(p);
	
	p=p/sum(p);
	z=find(mnrnd(1,p)>0);
end
function z=sampleLogMult(p)
	%p=p./sum(p);
	N=size(p,2);
	p1=zeros(1,N);
	for k=1:N
		sump=0;
		for l=1:N
			sump=sump+exp(p(1,l)-p(1,k));
		end
		p1(1,k)=1/sump;
	end
	p=p1;

	%z=find(mnrnd(1,p)>0);
	z=find(sample_hist(p',1)>0);
end

function [vec]=normalize(vec)
sumv=sum(vec);
vec=vec./sumv;
end

%This does not require any additional modification for test
function [ll perplexity]=llikelihood(data,Z,lambda)
VERY_SMALL_NUMBER=0.000001;
VERY_SMALL_LOG=-1000000000;
ll=0;
[T,M]=size(data);
K=max(Z);
%K=size(lambda,1);
	for i=1:M
		for k=1:K
			dtemp=0;
			ztemp=0;
			ltemp=0;
			for t=1:T
				dtemp=dtemp+(Z(t)==k)*data(t,i);				
				ztemp=ztemp+(Z(t)==k);
				%ltemp=ltemp+(Z(t)==k)*lambda(k,j); 
			end
			if lambda(k,i)>VERY_SMALL_NUMBER
				ll=ll+dtemp*log(lambda(k,i))-lambda(k,i)*ztemp;
			else
				ll=ll+dtemp*VERY_SMALL_LOG-lambda(k,i)*ztemp;
			end
			if isnan(ll)
				display(sprintf('%d %f \n',dtemp,lambda(k,i)));
			end
		end
		for t=1:T
			%gammaln (x+1) is a substitute for logfactorial x
			ll=ll-gammaln(data(t,i)+1);
		end
	end
	perplexity=exp(-1*ll/size(Z,2)/M);
end


function logtable=createlogtable(data)
N=max(max(data))*20;
logtable=zeros(1,N);
for i =1:N
		logtable(i)=log(i);
	end
end

function T = tridiag(a, b, c, n)
T = b*diag(ones(n,1)) + c*diag(ones(n-1,1),1) + a*diag(ones(n-1,1),-1);
end


%A quick implementation of viterbi algorithm for state decoding%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function p=logemissionIP(X,lambda)
p=0;
M=size(X,2);
for i=1:M
		p=p+log(lambda(i))-gammaln(X(i)+1)-lambda(i);
	end
end

function [Z]=hdphmm_viterbi(data,model)
lambda=model.lambda;
pkl=model.pkl;
pk=model.pk;
[T M]=size(data);
K=size(lambda,1);
Z=zeros(1,T);
obj=zeros(T,K);	

for k=1:K
		obj(1,k)=log(pk(k))+logemissionIP(data(1,:),lambda(k,:));
		path(1,k)=0;
	end

	for t=2:T
		for l=1:K
			[obj(t,l) path(t,l)]=max(obj(t-1,:)'+log(pkl(:,l)));
			obj(t,l)=logemissionIP(data(t,:),lambda(l,:))+obj(t,l);
		end

	end
	[m Z(T)]=max(obj(T,:));
	for t=T-1:-1:1
		Z(t)=path(t+1,Z(t+1));
	end
	Z'
end
