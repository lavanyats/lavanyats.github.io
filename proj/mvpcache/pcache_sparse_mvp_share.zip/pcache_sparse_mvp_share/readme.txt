If you use this code in your research, please reference 
----------------------------------------------------------------------------------------------------------------------------------------
Mining Block I/O Traces for Cache Preloading with Sparse Temporal Non-parametric Mixture of Multivariate Poisson, Lavanya Sita Tekumalla, Chiranjib Bhattacharyya, In proceedings of SIAM Data Mining Conference, 2015.
----------------------------------------------------------------------------------------------------------------------------------------

The mvp_hdphmm implements HMM-DP-MMVP while sparse_mvp_hdphmm implements Sparse-HMM-DP-MMVP.
Sample count vectors are available in datafile.csv

dat=load('datafile.csv');
[Z lambda]=mvp_hdphmm(dat,100,'tmp.mdata');
[Z lambda b]=sparse_mvp_hdphmm(dat,100,'tmp.mdata');

The parameters indicate the input data matrix with each row as one datapoint ,number of iterations and output file.
