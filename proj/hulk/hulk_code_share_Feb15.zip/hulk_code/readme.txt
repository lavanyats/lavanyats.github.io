Sample count vectors are available in datafile.csv

dat=load('datafile.csv');
[Z lambda b]=rll_copula_hdphmm(dat,100,'tmp.mdata');

The parameters indicate the input data matrix with each row as one datapoint ,number of iterations and output file.
