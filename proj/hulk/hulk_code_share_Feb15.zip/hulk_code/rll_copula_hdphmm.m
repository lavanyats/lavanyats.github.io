function [Z mu ll pkl beta model covar]= rll_copula_hdphmm(datafile,maxIter,outfile,trmodel,type_param,param_a,param_b)
	%Input : can pass either data file or data array and number of iterations

	type=0;
	paramin_a=1;paramin_b=.1;
	if exist('type_param') && ~isempty(type_param)
		type=type_param;
	end
	if exist('param_a') && ~isempty(param_a) paramin_a=param_a;end
	if exist('param_b') && ~isempty(param_b) paramin_b=param_b;end
		paramin_a
		paramin_b
	rll=1;

	global target;
	target=2;
	alpha=.1;gamma=paramin_b; %concentration parameters of hdp

	%From MVP code 
	global VERY_SMALL_LOG;
	global VERY_SMALL_NUMBER;
	VERY_SMALL_LOG=-1000000000;
	VERY_SMALL_NUMBER=0.00000001;
	rng(2);
	randomseed([3 4 5]);

	if isempty(maxIter) maxIter=100; 
	end %number of gibbs iterations
	display(sprintf('Maximum gibbs iter = %d',maxIter));

	if isempty(outfile)
		outfile='res_copula_hdphmm.mat';
	end

	data=[];
	if ischar(datafile) data=csvread(datafile);
	else data=datafile;
	end

	global logtable;
	%logtable=createlogtable(data);


	data=data ;
	[T M]=size(data)
	K=0;
	%data([14000:15000,1:20])

	ab=1*ones(1,M);
	bb=1*ones(1,M);
	aw=1*ones(1,M);
	bw=1*ones(1,M);

	covar=zeros(K+1,M,M);
	mu=zeros(K+1,M);
	naive_mu=zeros(K+1,M);

	%Random variables to be sampled
	Z=ones(1,T);
	Z(:,:)=-1;
	Y=zeros(T,M);
	Y=data;
	if(rll)
		for t=1:T
			for j=1:M
				%Y(t,j)=norminv(normcdf(data(t,j)),1);
				%Y(t,j)=norminv(poisscdf(data(t,j),1000),100);
	       		end
		end
	end
	Ranks=zeros(T,M);
	for j=1:M
		 [~, ~ ,tmp]=unique(Y(:,j));
		 Ranks(:,j)=tmp;
	end
	minY=min(Y);
	maxY=max(Y);

	%mean_mu=mean(Y);
	mean_mu=zeros(1,M);
	data_sd=std(Y)*std(Y)';
	%sigma_mu=10^M;
	sigma_mu=data_sd^0.5;
	%S0=eye(M)*(data_sd^paramin_a);
	n0=M;
	S0=eye(M)*10^-2;

	mcount=size(1,K+1);
	beta=ones(1,K+1);

	mcount(1)=1;mcount(2)=gamma;
	beta(K+1)=alpha;
	beta=normalize(beta);
	%Initialize with 0 topics
	numk=zeros(1,K+1);
	numkl=zeros(K+1,K+1);
	%y_sum_ki=zeros(K+1,M);
	b=ones(K+1,M);
	%data([14000:15000,1:20])

	numcj=K.*ones(1,M);
	size(numcj)
	numwj=zeros(1,M);
	mcount(1)=gamma;
	beta(1)=1;

	if exist('trmodel') && ~isempty(trmodel)
		mcount=trmodel.mcount;
		numkl=trmodel.numkl;
		numk=trmodel.numk;
		beta=trmodel.beta;
		covar=trmodel.covar;
		mu=trmodel.mu;
		mu=trmodel.mu;
		alpha=trmodel.alpha;
		gamma=trmodel.gamma;
		al=trmodel.al;
		bl=trmodel.bl;
		K=trmodel.K;
		numcj=trmodel.numcj;
		numwj=trmodel.numwj;
		ab=trmodel.ab;
		bb=trmodel.bb;
		aw=trmodel.aw;
		bw=trmodel.bw;
		b=trmodel.b;
	end

	total_timerval=tic;
	Z_old=Z;
	
	iter_time_arr=[];
	ll_arr=[];

	%Actually sampling
	for iter=1:maxIter
	        display(sprintf('sparse_copula_hdphmm Type %d  Gibbs iter %d/%d, K=%d\n',type,iter,maxIter,K));
		iter_time=tic;
		tic
	        for t=1:T
			  if ~mod(t,200) 
				  toc
				  display(sprintf('sparse_copula_hdphmm Type %d Gibbs iter iter=%d t= %d/%d K=%d \n',type,iter,t,T,K));  
				  tic
	     	    		  %ll=lpseudolikelihood(data(:,:),Y,Z,covar,b);
		    	  end
		    z_old=Z(t);
		    if t>1  z_prev=Z(t-1); else z_prev=-1; 
		    end
		    if t<T && iter~=1  z_next=Z(t+1); else z_next=-1; 
		    end
		    if iter~=1
			    [numk numkl  K beta mcount ]=remove(t,z_old,z_prev,z_next,numk,numkl,b,K,M,beta,mcount,data,Y);
	    	    end		    

		    %display('sampling z');
		    [Z(t) mu covar numwj]= sample_z_collapsed(t,Z,numkl,numk,numcj,numwj,K,alpha,beta,data,Y,aw,bw,ab,bb,mu,covar,b,mean_mu,sigma_mu,Ranks,rll,iter,S0,n0,paramin_a);

		    [numk numkl K ,beta mcount Z mu covar b numcj ]=addcompact(t,Z(t),z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,Z,mu,covar,b,numcj);
	      end
	      toc;
	     Z_old=Z;
	     display(sprintf('gibbs iter %d %d \n',iter,t));
	     %numk
	     mcount=sample_m(beta,numk,alpha,gamma,K); 
	     beta=sample_beta(mcount);
	     
	     display('finished sampling beta and m');

	     [mu]=samplemuAll(Z,data,Y,b,K,numk,covar,mean_mu,sigma_mu);
	     [covar ]=sampleCovarAll(Z,data,Y,b,K,numk,mu,S0,n0);

	     display('mean and covar being sampled');
	     %covar%

	     if(rll)
		     [Y ]= sample_y(Z,numk,data,Y,mu,covar,Ranks,minY,maxY);
	     end

	     ll=lpseudolikelihood(data(:,:),Y,Z,mu,covar,b);
	     ll_arr=[ll_arr ll];

	     for k=1:K
		     naive_mu(k,:)=mean(data(Z==k,:));
	     end
	     model.Z=Z;
	     model.iter_time_arr=iter_time_arr;
	     model.beta=beta;
	     model.Z=Z;
	     model.ll=ll;
	     model.b=b;
	     model.Y=Y;
             model.mcount=mcount;
	     model.numkl=numkl;
	     model.numk=numk;
	     model.beta=beta;
	     model.covar=covar;
	     model.mu=mu;
	     model.alpha=alpha;
	     model.gamma=gamma;
	     %model.al=al;
	     %model.bl=bl;
	     model.K=K;
	     model.numcj=numcj;
	     model.numwj=numwj;
	     model.ab=ab;
	     model.bb=bb;
	     model.aw=aw;
	     model.ll_arr=ll_arr;
	     model.type='rll_copula_hdphmm';
	     model.naive_mu=naive_mu;

	     save(outfile,'-struct','model');
	     display(sprintf('likelihood = %f with K=%d\n',ll,K));
	     iter_time_arr(iter)=toc(iter_time);
       	end
        total_elapsed_time=toc(total_timerval);;

	%Find transition probabilities
	pkl=zeros(K,K);
	%numkl
	for k=1:K
	  pkl(k,:)=numkl(k,1:K)./sum(numkl(k,1:K));
	end
	pk=numk(1:K)/sum(numk(1:K));

	%Find mean parameter
	%covar=meanEmissionParam(Z,data,al,bl,K);
	%[covar covarW ]=sampleCovarAll(Z,data,Y,b,K,numk);

	model.covar=covar;
	model.mu=mu;
	model.pkl=pkl;
	model.pk=pk;
	model.beta=beta;
	model.Z=Z;
	model.ll=ll;
	model.numkl=numkl;
	model.numk=numk;
	model.b=b;
	model.Y=Y;
	model.total_elapsed_time=total_elapsed_time;
	model.iter_time_arr=iter_time_arr;

        model.mcount=mcount;
	model.numkl=numkl;
	model.numk=numk;
	model.beta=beta;
	model.alpha=alpha;
	model.gamma=gamma;
	%model.al=al;
	%model.bl=bl;
	model.K=K;
	model.numcj=numcj;
	model.numwj=numwj;
	model.ab=ab;
	model.bb=bb;
	model.aw=aw;
	model.bw=bw;
	model.ll=ll;
	model.ll_arr=ll_arr;
	model.type='rll_copula_hdphmm';
	model.naive_mu=naive_mu;
	if exist('trmodel') && ~isempty(trmodel)
		model.prevll=trmodel.ll;
	end

	%Now estimate the state sequence Z using the viterbi algorithm to get a proper estimate of the state sequence
	%Z=copula_hdphmm_viterbi(data,model);
	model.Z=Z;

	save(outfile,'-struct','model');
	Z=Z'; 
	%[data Z]
	%[data Z b(1:100,:)]
	Z'
	%covar
	%b 
	for k=1:K
		squeeze(covar(k,:,:));
	end
	%b
	if exist('trmodel') && ~isempty(trmodel)
		display(sprintf('obtained %d clusters previously with likelihood=%f',trmodel.K,trmodel.ll));
	end
	display(sprintf('obtained %d clusters with likelihood=%f',size(covar,1),ll));
	%covarW

	%numk
	%Print result
	%beta
	%mcount
	%covar

end

function [z mu_out covar_out numwj_out]=sample_z_collapsed(t,Z,numkl,numk,numcj,numwj,K,alpha,beta,data,Y,aw,bw,ab,bb,mu,covar,b,mean_mu,sigma_mu,Ranks,rll,iter,S0,n0,paramin_a)
	VERY_SMALL_LOG=-10000000000000000000;
	VERY_SMALL_NUMBER=0.00000001;
	z_old=Z(t);
	[T M]=size(data);
	covarnew=zeros(M,M);
	munew=zeros(1,M);
	%if  Z(t)>0 y_sum_kjl(z_old,:,:)=y_sum_kjl(z_old,:,:)-Y(t,:,:); end
	eligible=ones(1,K);
	if(rll)
        	eligible=get_eligible_clusters(t,Z,numkl,numk,numcj,numwj,K,alpha,beta,data,Y,aw,bw,ab,bb,mu,covar,b,mean_mu,sigma_mu,Ranks,rll);
		if((sum(Z==-1))==0) eligible(z_old)=1;end
	end	

	data_std=(std(Y)*std(Y)');
	p=zeros(1,K+1);
	for k=1:K+1
		term_prev=1; if t>1 term_prev=(numkl(Z(t-1),k)+alpha*beta(k)); end
		term_next=1; if (t<size(data,1) && Z(t+1)~=-1)  term_next = (numkl(k,Z(t+1))+alpha*beta(Z(t+1)))/ (numk(k)+alpha) ; end
		emis=VERY_SMALL_LOG;
		if Z(t)>=0
			bind=find(b(Z(t),:)>0);
		else
			bind=ones(M);
		end

		if k==K+1
			MH_STEPS=10;
			s=0;
			emis_exp=0;
			b_old=ones(1,M);
			if z_old > 0
				b_old=b(z_old,:);
			end
			%while s<MH_STEPS
				%propose new value for b				
				%generage b_k+1 sample somehow 
				%[b(K+1,:) pr numSamples]=generateMHSample(b_old,0.2,ab,bb,numcj,K);
				%emis_temp=logemissionMVPCollapsed(t,k,Z,numk,data,Y,y_sum_kjl,b);
				%emis_temp=emis_temp+logemissionWCollapsed(t,k,Z,numk,data,Y,w_sum_j,aw,bw,b);
				%emis_exp=logWeightedAverage(emis_exp, emis_temp,s,1);
				%s=s+1;
				%b_old=b(K+1,:);
			%end
			b(K+1,:)=1;
			covarnew=eye(M)*(data_std^paramin_a);
			munew=mvnrnd(Y(t,:),covarnew);
			%munew=mvnrnd(Y(t,:),eye(M)*(std(Y)*std(Y)'));
			%munew=samplemu(data(t,:),Y(t,:),b,eye(M)*10^(28+log10(mean(mean_mu))),mean_mu,sigma_mu);
			%display('here');covarnew
			emis=logemission(Y(t,:),b,covarnew,munew);
			covarnew=sampleCovar(k,Z,data(t,:),Y(t,:),b(k,:),K,1,munew,S0,n0)*data_std^paramin_a;
			
			%if(iter==1 && t==531)keyboard; end
			%emis=emis_exp;
		elseif(eligible(k)~=0)
			emis=logemission(Y(t,:),b,covar(k,:,:),mu(k,:));
		end

	   	 %emis=  logemissionCollapsed(t,k,Z,numk,data,y_sum_ki,al,bl); %From HDPHMM
	        if term_prev==0 || term_next==0
		    p(1,K)=VERY_SMALL_NUMBER;
	        else 
	    		p(1,k)=log(term_prev)+log(term_next)+emis;
		end
		%[t k emis log(term_prev) log(term_next)]
	    	if isnan(p(1,k))
		    [k K]
		    p
	    	    term_prev
		    term_next
		    emis
		    display(sprintf('k=%d termprev %f termnext %f emis %f p(1,k) %f \n',k,term_prev,term_next,emis,p(1,k)));
		    keyboard
	    	end
	    	%p(1,k)=term_prev * term_next * emis;
	    	%samplingdetails=[t term_prev term_next emis] %dbg
	    	%p(1,k) %dbg
	end	
	if ~isreal(p) 
		display('in sample z');
		p
		keyboard; 
	end
	z=sampleLogMult(p);
	%if(t>=345)
	%	p
	%	keyboard
	%end
	%keyboard


	if(size(z,2)==0)
		%keyboard;
		z=K+1;
		munew=Y(t,:);
	end;
		%display(sprintf('sampling for %d',t));
		%keyboard

	if z_old>0 numwj=numwj-(1-b(z_old,:));	end
	if z==(K+1) covar(K+1,:,:)=covarnew; mu(K+1,:)=Y(t,:); end
	%if z==(K+1) covar(K+1,:,:)=covarnew; mu(K+1,:)=munew; end
	numwj=numwj+(1-b(z,:));
	covar_out=covar;
	mu_out=mu;
	numwj_out=numwj;
	%p=p./sum(p);
	%z=find(mnrnd(1,p)>0);	
end

function [beta]=sample_beta(mcount)
	beta=drchrnd(mcount,1);
end

function [mcount]=sample_m(beta,numk,alpha,gamma,K)
	mcount=zeros(1,K+1);
	for k=1:K
		tot=numk(k);
		totsofar=0;
		for c=1:tot
			x=alpha*beta(k)/(alpha*beta(k)+totsofar);
			totsofar=totsofar+1;
			if rand()<x
				mcount(k)=mcount(k)+1;
			end
		end
	end
	mcount(K+1)=gamma;
end


function [em]=logemissionCluster(k,Z,data,Y,aw,bw,b,covar,mu)
	%display('emission');
	[T M]=size(data);
	kind=find(Z==k)
	res=0;
	for t=kind
		res=res+log(mvnpdf(Y(t,:),mu(k,:),squeeze(covar(k,:,:))));
	end
	em=res;
end
function [em]=logemission(Yt,b,covark,muk)
	%display('emission');
	[T M]=size(Yt);
	if(length(size(covark))==3) covark=squeeze(covark); end
	res=log(mvnpdf(Yt,muk,eye(M)+squeeze(covark(:,:))));
	em=res;
%	if(isinf(em)) display('infinite emission'); keyboard; end
end


function [covar ]=sampleCovarAll(Z,data,Y,b,K,numk,mu,S0,n0)
	[T,M]=size(data);
	covar=zeros(K,M,M);
	for k=1:K
		%only kth componant is updated
		%if(sum(Z==k)>=M)
		%	covar(k,:,:)=cov(Y(Z==k,:));
		%else
			covar(k,:,:)=sampleCovar(k,Z,data(Z==k,:),Y(Z==k,:),b(k,:),K,numk(k),mu(k,:),S0,n0);
		%end
	end
			
end

function [covark ]=sampleCovar(k,Z,data,Yk,bk,K,numkk,mu,S0,n0)
	[T,M]=size(data);
	covark(:,:)=zeros(M,M);
	%for k=1:K
		covark(:,:)=eye(M);
		%S0=(10^(2+M/2))*eye(sum(bk));n0=M;
		S0_loc=S0(find(bk==1),find(bk==1));
		kind=find(Z==k);
		%cover(b(k,:),b(k,:))=wishrnd(S0,n0);
		Yn=Yk-ones(size(Yk))*diag(mu); %just doing Y(kind,:)-mu(k,:)
		warginv=S0_loc*n0+Yn'*Yn;                	     
		warg=inv(warginv);
		wsamp=wishrnd(warg,n0+numkk);
		covret=pinv(wsamp);
	        covret=tril(covret,-1)'+tril(covret);
		covark(find(bk==1),find(bk==1))=covret;
	%end
			
end

function [par_mu]=samplemuAll(Z,data,Y,b,K,numk,covar,mean_mu,sigma_mu)
        %print("sampling mean")
	     [T,M]=size(data);
	par_mu=zeros(K+1,M);
        for k=1:K
		%par_mu(k,:)=samplemu(data(Z==k,:),Y(Z==k,:),b,squeeze(covar(k,:,:)),mean_mu,sigma_mu);
	     	par_mu(k,:)=mean(Y(Z==k,:));
	end
end
function [sample_mu]=samplemu(data,Y,b,covar,mean_mu,sigma_mu)
	          % update mean for each cluster
	     [num,M]=size(data);
	     cmn=zeros(1,M); 
	     cmn=mean(Y(:,:),1);
	     mean_new=(num*cmn+sigma_mu^2*mean_mu)/(num+sigma_mu^2);
             var_new=covar(:,:)/(num+sigma_mu^2);
	     %var_adjusted=var_new+100*eye(M)*mean(mean(var_new))
	     %cond(var_adjusted)
	     %var_adjusted=tril(var_new,-1)'+tril(var_new)
	     %keyboard
             %sample_mu=mvnrnd(mean_new,var_new);
             sample_mu=mvnrnd(mean_new,1000*eye(M));
             if(sum(isinf(sample_mu)+isnan(sample_mu))>0 )
	              display('na in mean :(')
                      keyboard
	     end
end

%z_prev is z_t-1
function [numk_o numkl_o K_o  beta_o mcount_o ]=remove(t,z_old,z_prev,z_next,numk,numkl,b,K,M,beta,mcount,data,Y)
	numk(z_old)=numk(z_old)-1; 
	if z_prev ~= -1              numkl(z_prev,z_old)=numkl(z_prev,z_old)-1;  end
	if z_next ~= -1   		numkl(z_old,z_next)=numkl(z_old,z_next)-1;  end
	numk_o=numk;
	numkl_o=numkl;
	K_o=K;
	beta_o=beta;
	mcount_o=mcount;

end


function [elig]=get_eligible_clusters(t,Z,numkl,numk,numcj,numwj,K,alpha,beta,data,Y,aw,bw,ab,bb,mu,covar,b,mean_mu,sigma_mu,Ranks,rll)
	[T M]=size(data);
	elig=ones(1,K);
	for k=1:K
		%check if t is eligible to go to cluster k
		for j=1:M 
	          r=Ranks(t,j);
	          lb=max( Y( (Z==k) & (Ranks(:,j)<r)',j));
	          ub=min( Y( (Z==k) & (Ranks(:,j)>r)',j));
	          y=Y(t,j);
		  if(size(lb,1)==0 || size(ub,1)==0) elig(k)=1;
		  elseif((y > ub) || (y < lb)) elig(k)=0;end
	     	end
	end

end

function [Y_out ]= sample_y(Z,numk,data,Y,mu,covar,Ranks,minY,maxY)
	big=1000000000000000000;
	[T M]=size(data);
	
	for t=1:T
		k=Z(t);
		for j=1:M
			r=Ranks(t,j);
			%sample from truncated multivariate poission
 	                lower=max( Y( (Z==k) & (Ranks(:,j)<=r)',j) ) ;          
			upper=min( Y( (Z==k) & (Ranks(:,j)>=r)',j) ) ;
			if(size(lower,1)==0)lower=minY(j);end
			if(size(upper,1)==0)upper=maxY(j);end
			tmp_jmj=squeeze(covar(k,j,1:end ~= j))'; %row vec dim M-1
			tmp_mjmj=squeeze(covar(k,1:end~=j, 1:end~=j) ); %matrix M-1 x M-1
			tmp_mjj=squeeze(covar(k,1:end~=j,j))'; %column matrix
			m_new=mu(k,j)+ tmp_jmj*inv(tmp_mjmj) * (Y(t,1:end~=j)-mu(k,1:end~=j))';
			sigma_new=covar(k,j,j)-tmp_jmj*inv(tmp_mjmj)*tmp_mjj;

			if(upper==lower)
				Y(t,j)=upper;
			else
				Y(t,j)=rmvnrnd(m_new,sigma_new,1,lower,upper);
			end
		end
	end
	Y_out=Y;
end

function [numk_o numkl_o K_o ,beta_o mcount_o Z_o,mu_o,covar_o, b_o,numcj_o ]=addcompact(t,z_new,z_old,z_prev,z_next,numk,numkl,K,M,beta,mcount,data,Y,Z,mu,covar,b,numcj)

%[z_prev z_next z_new z_old] %dbg 
%display(sprintf('z_new = %d K=%d z_prev=%d z_next=%d',z_new,K,z_prev,z_next)); %dbg
	if z_new>K
		display(sprintf('New cluster %d at sampe %d',z_new,t));
		K=K+1;
		numk(z_new)=1;
		numk(z_new+1)=0;
		numkl(z_new+1,:)=0;
		numkl(:,z_new+1)=0;   

		if z_prev ~= -1         numkl(z_prev,z_new)=1;  end
		if z_next ~=-1		numkl(z_new,z_next)=1;  end   
		if z_old ==-1
			b(z_new,:)=1;
		else 
			b(z_new,:)=1;
	%		w_sum_j=w_sum_j-(1-b(z_old,:)).*diag(squeeze(y_sum_kjl(z_old,:,:)))';
			%b(z_new,:)=b(z_old,:);
		end
		mcount(K+1)=mcount(K);
		b(z_new+1,:)=1;
		mcount(K)=1;
		beta=sample_beta(mcount);
		numcj=numcj+b(z_new,:);
		%numwj=numwj+(1-b(z_new,:));

	else 
		numk(z_new)=numk(z_new)+1;
		if z_prev ~= -1 		numkl(z_prev,z_new)=numkl(z_prev,z_new)+1; end
		if z_next ~= -1 		numkl(z_new,z_next)=numkl(z_new,z_next)+1; end
        end
	delind=find(numk(1:K)==0);
	numRemove=size(delind,2);
	if numRemove > 0
		   %numk %dbg
		   display(sprintf('removing %d clusters',numRemove)); %dbg
		   %delind %dbg

		   %Z %dbg
		   %change cluster indices
		   for d=1:numRemove
			   kdel=delind(d);

			   templist=find(Z>kdel);
			   Z(templist)=Z(templist)-1;

			   templist=find(delind>kdel);
			   delind(templist)=delind(templist)-1;
		end
		%Z %dbg

		numcj=numcj-sum(b(delind,:),1);
		K=K-size(delind,2);
		numk(delind)=[];
		numkl(delind,:)=[];
		numkl(:,delind)=[];
		beta(delind)=[];
		mcount(delind)=[];
		b(delind,:)=[];
		covar(delind,:,:)=[];
		mu(delind,:)=[];
	end


	numk_o=numk;
	numkl_o=numkl;
	K_o=K;
	Z_o=Z;
	beta_o=beta;
	mcount_o=mcount;
	covar_o=covar;
	mu_o=mu;
	b_o=b;
	numcj_o=numcj;

end

function r = drchrnd(a,n)
p = length(a);
r = gamrnd(repmat(a,n,1),1,n,p);
r = r ./ repmat(sum(r,2),1,p);
end

function z=sampleLogMultFast(p)
	mp=max(p);
	p(:,:)=p(:,:)-mp;
	p=exp(p);
	
	p=p/sum(p);
	z=find(mnrnd(1,p)>0);
end
function z=sampleLogMult(p)
	%p=p./sum(p);
	N=size(p,2);
	p1=zeros(1,N);
	for k=1:N
		sump=0;
		for l=1:N
			sump=sump+exp(p(1,l)-p(1,k));
		end
		p1(1,k)=1/sump;		
	end
	p=p1;
	%keyboard
	p(isnan(p))=0;
	z=find(mnrnd(1,p)>0);
	%z=find(sample_hist(p',1)>0);
end

function [vec]=normalize(vec)
sumv=sum(vec);
vec=vec./sumv;
end

function ll=lpseudolikelihood(data,Y,Z,mu,covar,b)
VERY_SMALL_NUMBER=0.000001;
VERY_SMALL_LOG=-1000000000000000000000000;
ll=0;
[T,M]=size(data);
K=max(Z);
lpl=0;
%K=size(covar,1);
	for k=1:K
		zind=find(Z==k);
		for t=zind
			lpl=lpl+log(mvnpdf(Y(t,:),mu(k,:),squeeze(covar(k,:,:))));			
		end
	end
end


function logtable=createlogtable(data)
N=max(max(data))*20;
logtable=zeros(1,N);
for i =1:N
		logtable(i)=log(i);
	end
end

function T = tridiag(a, b, c, n)
T = b*diag(ones(n,1)) + c*diag(ones(n-1,1),1) + a*diag(ones(n-1,1),-1);
end


function res=logWeightedAverage(la,lb,x,y)
	if x==0
		res=lb;
	elseif y==0
		res=la;
	else
		res1=exp(lb-la+log(y/x));
		if isinf(res1)
			res=(la+log(x)-log(x+y))+lb-la+log(y/x);
		else	
			res=(la+log(x)-log(x+y))+log(1+exp(lb-la+log(y/x)));
		end
	end
end
				

function b_post=get_b_posterior(b,ab,bb,numcj,K)
		b_post=prod(((ab(:)+numcj(:)-1)'.^b(1,:)+(bb(:)+K-numcj(:))'.^(1-b(1,:)))./(ab(:)+bb(:)+K)');
end
function [b_new pr numSamples]=generateMHSample(b_old,eta,ab,bb,numcj,K)
	a=0;
	%display('attempt mh sample');
	b_new=b_old;
	M=size(b_old,2);
	numSamples=0;
	while a<1
		%pr=zeros(1,M);
		b_new=b_old;
		for j=1:M
			if rand()<eta
				b_new(1,j)=1-b_old(1,j);
			end
		end		
		pr=get_b_posterior(b_new,ab,bb,numcj,K)/get_b_posterior(b_old,ab,bb,numcj,K);
		%pr=prod(((ab(:)+numcj(:)-1)'.^b_new(1,:)+(bb(:)+K-numcj(:))'.^(1-b_new(1,:)))./(ab(:)+bb(:)+K)');
		a=min(1, pr);
		numSamples=numSamples+1;
		if rand()<a
			return;
		end

		if mod(numSamples ,100)==0
			display(sprintf('%d samples %f ',numSamples,a));
		end
		if numSamples>15
			b_new=b_old;
			return;
		end

	end
end

function [Z]=copula_hdphmm_viterbi(data,model)
	covar=model.covar;
	Y=data;
	[T M]=size(data);
	mu=model.mu;
	pkl=model.pkl;
	pk=model.pk;
	covar=model.covar;
	b=model.b;
	K=length(unique(model.Z));
	Z=zeros(1,T);
	obj=zeros(T,K);

	%logemission(t,k,Z,Y,b,covar(k,:,:),mu(k,:))
	for k=1:K
        	obj(1,k)=log(pk(k))+logemission(Y(1,:),b(k,:),covar(k,:,:),mu(k,:));
		path(1,k)=0;
	end
        for t=2:T
               for l=1:K
		       [obj(t,l) path(t,l)]=max(obj(t-1,:)'+log(pkl(:,l)));
		       obj(t,l)=logemission(Y(t,:),b(l,:),covar(l,:,:),mu(l,:))+obj(t,l);
	       end
        end
        [m Z(T)]=max(obj(T,:));
        for t=T-1:-1:1
               Z(t)=path(t+1,Z(t+1));
        end
																		        Z'
end

